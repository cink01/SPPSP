﻿namespace SystemProPodporuStudijnichPlanu
{
    partial class FormMain
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.menuStripMain = new System.Windows.Forms.MenuStrip();
            this.souborToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vytvořitNovýZáznamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.upravitZáznamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.konecToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.správaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nápovědaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oAplikaciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lb_semestr2 = new System.Windows.Forms.ListBox();
            this.lb_semestr3 = new System.Windows.Forms.ListBox();
            this.lb_semestr4 = new System.Windows.Forms.ListBox();
            this.lb_semestr5 = new System.Windows.Forms.ListBox();
            this.lb_semestr6 = new System.Windows.Forms.ListBox();
            this.nud_celkemKred = new System.Windows.Forms.NumericUpDown();
            this.nud_KredSem1 = new System.Windows.Forms.NumericUpDown();
            this.nud_KredSem2 = new System.Windows.Forms.NumericUpDown();
            this.nud_KredSem3 = new System.Windows.Forms.NumericUpDown();
            this.nud_KredSem4 = new System.Windows.Forms.NumericUpDown();
            this.nud_KredSem5 = new System.Windows.Forms.NumericUpDown();
            this.nud_KredSem6 = new System.Windows.Forms.NumericUpDown();
            this.lb_celkem = new System.Windows.Forms.Label();
            this.btn_pridat = new System.Windows.Forms.Button();
            this.lb_semestr1 = new System.Windows.Forms.ListBox();
            this.lb_semestr8 = new System.Windows.Forms.ListBox();
            this.lb_semestr9 = new System.Windows.Forms.ListBox();
            this.lb_semestr10 = new System.Windows.Forms.ListBox();
            this.lb_semestr11 = new System.Windows.Forms.ListBox();
            this.lb_semestr12 = new System.Windows.Forms.ListBox();
            this.nud_KredSem7 = new System.Windows.Forms.NumericUpDown();
            this.nud_KredSem8 = new System.Windows.Forms.NumericUpDown();
            this.nud_KredSem9 = new System.Windows.Forms.NumericUpDown();
            this.nud_KredSem10 = new System.Windows.Forms.NumericUpDown();
            this.nud_KredSem11 = new System.Windows.Forms.NumericUpDown();
            this.nud_KredSem12 = new System.Windows.Forms.NumericUpDown();
            this.lb_semestr7 = new System.Windows.Forms.ListBox();
            this.bt_smaz = new System.Windows.Forms.Button();
            this.cmb_zaznam = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.gb_max = new System.Windows.Forms.GroupBox();
            this.kb_edit = new SystemProPodporuStudijnichPlanu.Icons.KulateButton();
            this.bt_addZaz = new SystemProPodporuStudijnichPlanu.Icons.KulateButton();
            this.bt_delZaz = new SystemProPodporuStudijnichPlanu.Icons.KulateButton();
            this.l_s8 = new System.Windows.Forms.Label();
            this.l_s12 = new System.Windows.Forms.Label();
            this.l_s11 = new System.Windows.Forms.Label();
            this.l_s10 = new System.Windows.Forms.Label();
            this.l_s9 = new System.Windows.Forms.Label();
            this.l_s7 = new System.Windows.Forms.Label();
            this.l_s6 = new System.Windows.Forms.Label();
            this.l_s5 = new System.Windows.Forms.Label();
            this.l_s4 = new System.Windows.Forms.Label();
            this.l_s3 = new System.Windows.Forms.Label();
            this.l_s2 = new System.Windows.Forms.Label();
            this.l_s1 = new System.Windows.Forms.Label();
            this.bt_zobrazDGar = new System.Windows.Forms.Button();
            this.l_vk = new System.Windows.Forms.Label();
            this.l_pvk = new System.Windows.Forms.Label();
            this.l_pkr = new System.Windows.Forms.Label();
            this.vypisPopisPredmet = new SystemProPodporuStudijnichPlanu.Komponenty.VypisPopisPredmet();
            this.nud_vKr = new System.Windows.Forms.NumericUpDown();
            this.nud_pvKr = new System.Windows.Forms.NumericUpDown();
            this.nud_pKr = new System.Windows.Forms.NumericUpDown();
            this.lb_vyber = new System.Windows.Forms.Label();
            this.nud_PridatDoSem = new System.Windows.Forms.NumericUpDown();
            this.toolTip_new = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_edit = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_del = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_pridat = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_smaz = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_garant = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip_sem = new System.Windows.Forms.ToolTip(this.components);
            this.vypisGarantMain = new SystemProPodporuStudijnichPlanu.Komponenty.VypisGarant();
            this.menuStripMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_celkemKred)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem12)).BeginInit();
            this.gb_max.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_vKr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_pvKr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_pKr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PridatDoSem)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStripMain
            // 
            this.menuStripMain.BackColor = System.Drawing.Color.Transparent;
            this.menuStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.souborToolStripMenuItem,
            this.správaToolStripMenuItem,
            this.nápovědaToolStripMenuItem});
            this.menuStripMain.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.menuStripMain.Location = new System.Drawing.Point(0, 0);
            this.menuStripMain.Name = "menuStripMain";
            this.menuStripMain.Size = new System.Drawing.Size(1094, 23);
            this.menuStripMain.TabIndex = 1;
            // 
            // souborToolStripMenuItem
            // 
            this.souborToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vytvořitNovýZáznamToolStripMenuItem,
            this.upravitZáznamToolStripMenuItem,
            this.konecToolStripMenuItem});
            this.souborToolStripMenuItem.Name = "souborToolStripMenuItem";
            this.souborToolStripMenuItem.Size = new System.Drawing.Size(57, 19);
            this.souborToolStripMenuItem.Text = "&Soubor";
            // 
            // vytvořitNovýZáznamToolStripMenuItem
            // 
            this.vytvořitNovýZáznamToolStripMenuItem.Name = "vytvořitNovýZáznamToolStripMenuItem";
            this.vytvořitNovýZáznamToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.vytvořitNovýZáznamToolStripMenuItem.Text = "Vytvořit nový záznam";
            this.vytvořitNovýZáznamToolStripMenuItem.Click += new System.EventHandler(this.VytvořitNovýZáznamToolStripMenuItem_Click);
            // 
            // upravitZáznamToolStripMenuItem
            // 
            this.upravitZáznamToolStripMenuItem.Name = "upravitZáznamToolStripMenuItem";
            this.upravitZáznamToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.upravitZáznamToolStripMenuItem.Text = "Upravit záznam";
            this.upravitZáznamToolStripMenuItem.Click += new System.EventHandler(this.UpravitZáznamToolStripMenuItem_Click);
            // 
            // konecToolStripMenuItem
            // 
            this.konecToolStripMenuItem.Name = "konecToolStripMenuItem";
            this.konecToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.konecToolStripMenuItem.Text = "&Konec";
            this.konecToolStripMenuItem.Click += new System.EventHandler(this.UkonceniProgramu);
            // 
            // správaToolStripMenuItem
            // 
            this.správaToolStripMenuItem.Name = "správaToolStripMenuItem";
            this.správaToolStripMenuItem.Size = new System.Drawing.Size(83, 19);
            this.správaToolStripMenuItem.Text = "&Vyhledávání";
            this.správaToolStripMenuItem.Click += new System.EventHandler(this.SprávaToolStripMenuItem_Click);
            // 
            // nápovědaToolStripMenuItem
            // 
            this.nápovědaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oAplikaciToolStripMenuItem});
            this.nápovědaToolStripMenuItem.Name = "nápovědaToolStripMenuItem";
            this.nápovědaToolStripMenuItem.Size = new System.Drawing.Size(73, 19);
            this.nápovědaToolStripMenuItem.Text = "&Nápověda";
            // 
            // oAplikaciToolStripMenuItem
            // 
            this.oAplikaciToolStripMenuItem.Name = "oAplikaciToolStripMenuItem";
            this.oAplikaciToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.oAplikaciToolStripMenuItem.Text = "O aplikaci";
            this.oAplikaciToolStripMenuItem.Click += new System.EventHandler(this.OAplikaciToolStripMenuItem_Click);
            // 
            // lb_semestr2
            // 
            this.lb_semestr2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lb_semestr2.FormattingEnabled = true;
            this.lb_semestr2.HorizontalScrollbar = true;
            this.lb_semestr2.ItemHeight = 15;
            this.lb_semestr2.Location = new System.Drawing.Point(82, 144);
            this.lb_semestr2.Name = "lb_semestr2";
            this.lb_semestr2.Size = new System.Drawing.Size(189, 94);
            this.lb_semestr2.TabIndex = 2;
            this.lb_semestr2.SelectedIndexChanged += new System.EventHandler(this.Lb_semestr2_SelectedIndexChanged);
            this.lb_semestr2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ListyZmacknutiKlavesy);
            // 
            // lb_semestr3
            // 
            this.lb_semestr3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lb_semestr3.FormattingEnabled = true;
            this.lb_semestr3.HorizontalScrollbar = true;
            this.lb_semestr3.ItemHeight = 15;
            this.lb_semestr3.Location = new System.Drawing.Point(82, 246);
            this.lb_semestr3.Name = "lb_semestr3";
            this.lb_semestr3.Size = new System.Drawing.Size(189, 94);
            this.lb_semestr3.TabIndex = 3;
            this.lb_semestr3.SelectedIndexChanged += new System.EventHandler(this.Lb_semestr3_SelectedIndexChanged);
            this.lb_semestr3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ListyZmacknutiKlavesy);
            // 
            // lb_semestr4
            // 
            this.lb_semestr4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lb_semestr4.FormattingEnabled = true;
            this.lb_semestr4.HorizontalScrollbar = true;
            this.lb_semestr4.ItemHeight = 15;
            this.lb_semestr4.Location = new System.Drawing.Point(82, 348);
            this.lb_semestr4.Name = "lb_semestr4";
            this.lb_semestr4.Size = new System.Drawing.Size(189, 94);
            this.lb_semestr4.TabIndex = 4;
            this.lb_semestr4.SelectedIndexChanged += new System.EventHandler(this.Lb_semestr4_SelectedIndexChanged);
            this.lb_semestr4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ListyZmacknutiKlavesy);
            // 
            // lb_semestr5
            // 
            this.lb_semestr5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lb_semestr5.FormattingEnabled = true;
            this.lb_semestr5.HorizontalScrollbar = true;
            this.lb_semestr5.ItemHeight = 15;
            this.lb_semestr5.Location = new System.Drawing.Point(82, 449);
            this.lb_semestr5.Name = "lb_semestr5";
            this.lb_semestr5.Size = new System.Drawing.Size(189, 94);
            this.lb_semestr5.TabIndex = 5;
            this.lb_semestr5.SelectedIndexChanged += new System.EventHandler(this.Lb_semestr5_SelectedIndexChanged);
            this.lb_semestr5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ListyZmacknutiKlavesy);
            // 
            // lb_semestr6
            // 
            this.lb_semestr6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lb_semestr6.FormattingEnabled = true;
            this.lb_semestr6.HorizontalScrollbar = true;
            this.lb_semestr6.ItemHeight = 15;
            this.lb_semestr6.Location = new System.Drawing.Point(82, 550);
            this.lb_semestr6.Name = "lb_semestr6";
            this.lb_semestr6.Size = new System.Drawing.Size(189, 94);
            this.lb_semestr6.TabIndex = 6;
            this.lb_semestr6.SelectedIndexChanged += new System.EventHandler(this.Lb_semestr6_SelectedIndexChanged);
            this.lb_semestr6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ListyZmacknutiKlavesy);
            // 
            // nud_celkemKred
            // 
            this.nud_celkemKred.BackColor = System.Drawing.Color.White;
            this.nud_celkemKred.Enabled = false;
            this.nud_celkemKred.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_celkemKred.Location = new System.Drawing.Point(1012, 547);
            this.nud_celkemKred.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_celkemKred.Name = "nud_celkemKred";
            this.nud_celkemKred.ReadOnly = true;
            this.nud_celkemKred.Size = new System.Drawing.Size(55, 20);
            this.nud_celkemKred.TabIndex = 7;
            this.nud_celkemKred.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_KredSem1
            // 
            this.nud_KredSem1.BackColor = System.Drawing.Color.White;
            this.nud_KredSem1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_KredSem1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.nud_KredSem1.Location = new System.Drawing.Point(276, 44);
            this.nud_KredSem1.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_KredSem1.Name = "nud_KredSem1";
            this.nud_KredSem1.ReadOnly = true;
            this.nud_KredSem1.Size = new System.Drawing.Size(56, 20);
            this.nud_KredSem1.TabIndex = 8;
            this.nud_KredSem1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_KredSem1.ValueChanged += new System.EventHandler(this.ZmenaKredituVNUD);
            // 
            // nud_KredSem2
            // 
            this.nud_KredSem2.BackColor = System.Drawing.Color.White;
            this.nud_KredSem2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_KredSem2.Location = new System.Drawing.Point(276, 145);
            this.nud_KredSem2.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_KredSem2.Name = "nud_KredSem2";
            this.nud_KredSem2.ReadOnly = true;
            this.nud_KredSem2.Size = new System.Drawing.Size(55, 20);
            this.nud_KredSem2.TabIndex = 9;
            this.nud_KredSem2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_KredSem2.ValueChanged += new System.EventHandler(this.ZmenaKredituVNUD);
            // 
            // nud_KredSem3
            // 
            this.nud_KredSem3.BackColor = System.Drawing.Color.White;
            this.nud_KredSem3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_KredSem3.Location = new System.Drawing.Point(276, 246);
            this.nud_KredSem3.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_KredSem3.Name = "nud_KredSem3";
            this.nud_KredSem3.ReadOnly = true;
            this.nud_KredSem3.Size = new System.Drawing.Size(55, 20);
            this.nud_KredSem3.TabIndex = 10;
            this.nud_KredSem3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_KredSem3.ValueChanged += new System.EventHandler(this.ZmenaKredituVNUD);
            // 
            // nud_KredSem4
            // 
            this.nud_KredSem4.BackColor = System.Drawing.Color.White;
            this.nud_KredSem4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_KredSem4.Location = new System.Drawing.Point(276, 348);
            this.nud_KredSem4.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_KredSem4.Name = "nud_KredSem4";
            this.nud_KredSem4.ReadOnly = true;
            this.nud_KredSem4.Size = new System.Drawing.Size(55, 20);
            this.nud_KredSem4.TabIndex = 11;
            this.nud_KredSem4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_KredSem4.ValueChanged += new System.EventHandler(this.ZmenaKredituVNUD);
            // 
            // nud_KredSem5
            // 
            this.nud_KredSem5.BackColor = System.Drawing.Color.White;
            this.nud_KredSem5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_KredSem5.Location = new System.Drawing.Point(276, 449);
            this.nud_KredSem5.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_KredSem5.Name = "nud_KredSem5";
            this.nud_KredSem5.ReadOnly = true;
            this.nud_KredSem5.Size = new System.Drawing.Size(55, 20);
            this.nud_KredSem5.TabIndex = 12;
            this.nud_KredSem5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_KredSem5.ValueChanged += new System.EventHandler(this.ZmenaKredituVNUD);
            // 
            // nud_KredSem6
            // 
            this.nud_KredSem6.BackColor = System.Drawing.Color.White;
            this.nud_KredSem6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_KredSem6.Location = new System.Drawing.Point(276, 550);
            this.nud_KredSem6.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_KredSem6.Name = "nud_KredSem6";
            this.nud_KredSem6.ReadOnly = true;
            this.nud_KredSem6.Size = new System.Drawing.Size(55, 20);
            this.nud_KredSem6.TabIndex = 13;
            this.nud_KredSem6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_KredSem6.ValueChanged += new System.EventHandler(this.ZmenaKredituVNUD);
            // 
            // lb_celkem
            // 
            this.lb_celkem.AutoSize = true;
            this.lb_celkem.Location = new System.Drawing.Point(925, 549);
            this.lb_celkem.Name = "lb_celkem";
            this.lb_celkem.Size = new System.Drawing.Size(81, 13);
            this.lb_celkem.TabIndex = 14;
            this.lb_celkem.Text = "Celkem Kreditů:";
            // 
            // btn_pridat
            // 
            this.btn_pridat.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_pridat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_pridat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_pridat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_pridat.Location = new System.Drawing.Point(574, 9);
            this.btn_pridat.Name = "btn_pridat";
            this.btn_pridat.Size = new System.Drawing.Size(104, 26);
            this.btn_pridat.TabIndex = 14;
            this.btn_pridat.Text = "&Přidat";
            this.toolTip_pridat.SetToolTip(this.btn_pridat, "Přidat předměty do zvoleného semestru");
            this.btn_pridat.UseVisualStyleBackColor = false;
            this.btn_pridat.Click += new System.EventHandler(this.Bt_proved_Click);
            // 
            // lb_semestr1
            // 
            this.lb_semestr1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lb_semestr1.FormattingEnabled = true;
            this.lb_semestr1.HorizontalScrollbar = true;
            this.lb_semestr1.ItemHeight = 15;
            this.lb_semestr1.Location = new System.Drawing.Point(82, 44);
            this.lb_semestr1.Name = "lb_semestr1";
            this.lb_semestr1.Size = new System.Drawing.Size(189, 94);
            this.lb_semestr1.TabIndex = 1;
            this.lb_semestr1.SelectedIndexChanged += new System.EventHandler(this.Lb_semestr1_SelectedIndexChanged);
            this.lb_semestr1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ListyZmacknutiKlavesy);
            // 
            // lb_semestr8
            // 
            this.lb_semestr8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lb_semestr8.FormattingEnabled = true;
            this.lb_semestr8.HorizontalScrollbar = true;
            this.lb_semestr8.ItemHeight = 15;
            this.lb_semestr8.Location = new System.Drawing.Point(428, 143);
            this.lb_semestr8.Name = "lb_semestr8";
            this.lb_semestr8.Size = new System.Drawing.Size(189, 94);
            this.lb_semestr8.TabIndex = 8;
            this.lb_semestr8.SelectedIndexChanged += new System.EventHandler(this.Lb_semestr8_SelectedIndexChanged);
            this.lb_semestr8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ListyZmacknutiKlavesy);
            // 
            // lb_semestr9
            // 
            this.lb_semestr9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lb_semestr9.FormattingEnabled = true;
            this.lb_semestr9.HorizontalScrollbar = true;
            this.lb_semestr9.ItemHeight = 15;
            this.lb_semestr9.Location = new System.Drawing.Point(429, 245);
            this.lb_semestr9.Name = "lb_semestr9";
            this.lb_semestr9.Size = new System.Drawing.Size(189, 94);
            this.lb_semestr9.TabIndex = 9;
            this.lb_semestr9.SelectedIndexChanged += new System.EventHandler(this.Lb_semestr9_SelectedIndexChanged);
            this.lb_semestr9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ListyZmacknutiKlavesy);
            // 
            // lb_semestr10
            // 
            this.lb_semestr10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lb_semestr10.FormattingEnabled = true;
            this.lb_semestr10.HorizontalScrollbar = true;
            this.lb_semestr10.ItemHeight = 15;
            this.lb_semestr10.Location = new System.Drawing.Point(428, 347);
            this.lb_semestr10.Name = "lb_semestr10";
            this.lb_semestr10.Size = new System.Drawing.Size(189, 94);
            this.lb_semestr10.TabIndex = 10;
            this.lb_semestr10.SelectedIndexChanged += new System.EventHandler(this.Lb_semestr10_SelectedIndexChanged);
            this.lb_semestr10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ListyZmacknutiKlavesy);
            // 
            // lb_semestr11
            // 
            this.lb_semestr11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lb_semestr11.FormattingEnabled = true;
            this.lb_semestr11.HorizontalScrollbar = true;
            this.lb_semestr11.ItemHeight = 15;
            this.lb_semestr11.Location = new System.Drawing.Point(428, 448);
            this.lb_semestr11.Name = "lb_semestr11";
            this.lb_semestr11.Size = new System.Drawing.Size(189, 94);
            this.lb_semestr11.TabIndex = 11;
            this.lb_semestr11.SelectedIndexChanged += new System.EventHandler(this.Lb_semestr11_SelectedIndexChanged);
            this.lb_semestr11.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ListyZmacknutiKlavesy);
            // 
            // lb_semestr12
            // 
            this.lb_semestr12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lb_semestr12.FormattingEnabled = true;
            this.lb_semestr12.HorizontalScrollbar = true;
            this.lb_semestr12.ItemHeight = 15;
            this.lb_semestr12.Location = new System.Drawing.Point(428, 549);
            this.lb_semestr12.Name = "lb_semestr12";
            this.lb_semestr12.Size = new System.Drawing.Size(189, 94);
            this.lb_semestr12.TabIndex = 12;
            this.lb_semestr12.SelectedIndexChanged += new System.EventHandler(this.Lb_semestr12_SelectedIndexChanged);
            this.lb_semestr12.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ListyZmacknutiKlavesy);
            // 
            // nud_KredSem7
            // 
            this.nud_KredSem7.BackColor = System.Drawing.Color.White;
            this.nud_KredSem7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_KredSem7.ForeColor = System.Drawing.SystemColors.WindowText;
            this.nud_KredSem7.Location = new System.Drawing.Point(623, 43);
            this.nud_KredSem7.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_KredSem7.Name = "nud_KredSem7";
            this.nud_KredSem7.ReadOnly = true;
            this.nud_KredSem7.Size = new System.Drawing.Size(55, 20);
            this.nud_KredSem7.TabIndex = 40;
            this.nud_KredSem7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_KredSem7.ValueChanged += new System.EventHandler(this.ZmenaKredituVNUD);
            // 
            // nud_KredSem8
            // 
            this.nud_KredSem8.BackColor = System.Drawing.Color.White;
            this.nud_KredSem8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_KredSem8.Location = new System.Drawing.Point(623, 144);
            this.nud_KredSem8.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_KredSem8.Name = "nud_KredSem8";
            this.nud_KredSem8.ReadOnly = true;
            this.nud_KredSem8.Size = new System.Drawing.Size(54, 20);
            this.nud_KredSem8.TabIndex = 41;
            this.nud_KredSem8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_KredSem8.ValueChanged += new System.EventHandler(this.ZmenaKredituVNUD);
            // 
            // nud_KredSem9
            // 
            this.nud_KredSem9.BackColor = System.Drawing.Color.White;
            this.nud_KredSem9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_KredSem9.Location = new System.Drawing.Point(623, 245);
            this.nud_KredSem9.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_KredSem9.Name = "nud_KredSem9";
            this.nud_KredSem9.ReadOnly = true;
            this.nud_KredSem9.Size = new System.Drawing.Size(54, 20);
            this.nud_KredSem9.TabIndex = 42;
            this.nud_KredSem9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_KredSem9.ValueChanged += new System.EventHandler(this.ZmenaKredituVNUD);
            // 
            // nud_KredSem10
            // 
            this.nud_KredSem10.BackColor = System.Drawing.Color.White;
            this.nud_KredSem10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_KredSem10.Location = new System.Drawing.Point(623, 347);
            this.nud_KredSem10.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_KredSem10.Name = "nud_KredSem10";
            this.nud_KredSem10.ReadOnly = true;
            this.nud_KredSem10.Size = new System.Drawing.Size(54, 20);
            this.nud_KredSem10.TabIndex = 43;
            this.nud_KredSem10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_KredSem10.ValueChanged += new System.EventHandler(this.ZmenaKredituVNUD);
            // 
            // nud_KredSem11
            // 
            this.nud_KredSem11.BackColor = System.Drawing.Color.White;
            this.nud_KredSem11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_KredSem11.Location = new System.Drawing.Point(623, 448);
            this.nud_KredSem11.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_KredSem11.Name = "nud_KredSem11";
            this.nud_KredSem11.ReadOnly = true;
            this.nud_KredSem11.Size = new System.Drawing.Size(54, 20);
            this.nud_KredSem11.TabIndex = 44;
            this.nud_KredSem11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_KredSem11.ValueChanged += new System.EventHandler(this.ZmenaKredituVNUD);
            // 
            // nud_KredSem12
            // 
            this.nud_KredSem12.BackColor = System.Drawing.Color.White;
            this.nud_KredSem12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_KredSem12.Location = new System.Drawing.Point(624, 549);
            this.nud_KredSem12.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_KredSem12.Name = "nud_KredSem12";
            this.nud_KredSem12.ReadOnly = true;
            this.nud_KredSem12.Size = new System.Drawing.Size(54, 20);
            this.nud_KredSem12.TabIndex = 45;
            this.nud_KredSem12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nud_KredSem12.ValueChanged += new System.EventHandler(this.ZmenaKredituVNUD);
            // 
            // lb_semestr7
            // 
            this.lb_semestr7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lb_semestr7.FormattingEnabled = true;
            this.lb_semestr7.HorizontalScrollbar = true;
            this.lb_semestr7.ItemHeight = 15;
            this.lb_semestr7.Location = new System.Drawing.Point(428, 43);
            this.lb_semestr7.Name = "lb_semestr7";
            this.lb_semestr7.Size = new System.Drawing.Size(189, 94);
            this.lb_semestr7.TabIndex = 7;
            this.lb_semestr7.SelectedIndexChanged += new System.EventHandler(this.Lb_semestr7_SelectedIndexChanged);
            this.lb_semestr7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ListyZmacknutiKlavesy);
            // 
            // bt_smaz
            // 
            this.bt_smaz.BackColor = System.Drawing.Color.LightCoral;
            this.bt_smaz.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_smaz.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt_smaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bt_smaz.Location = new System.Drawing.Point(684, 9);
            this.bt_smaz.Name = "bt_smaz";
            this.bt_smaz.Size = new System.Drawing.Size(104, 26);
            this.bt_smaz.TabIndex = 16;
            this.bt_smaz.Text = "Smaž vybraný";
            this.toolTip_smaz.SetToolTip(this.bt_smaz, "Smazat vybraný předmět ze semestru");
            this.bt_smaz.UseVisualStyleBackColor = false;
            this.bt_smaz.Visible = false;
            this.bt_smaz.Click += new System.EventHandler(this.Bt_smaz_Click);
            // 
            // cmb_zaznam
            // 
            this.cmb_zaznam.FormattingEnabled = true;
            this.cmb_zaznam.ItemHeight = 13;
            this.cmb_zaznam.Location = new System.Drawing.Point(159, 12);
            this.cmb_zaznam.Name = "cmb_zaznam";
            this.cmb_zaznam.Size = new System.Drawing.Size(113, 21);
            this.cmb_zaznam.TabIndex = 0;
            this.toolTip_sem.SetToolTip(this.cmb_zaznam, "Výběr plánu");
            this.cmb_zaznam.SelectedIndexChanged += new System.EventHandler(this.Cmb_zaznam_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(80, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 63;
            this.label2.Text = "Výběr plánu:";
            // 
            // gb_max
            // 
            this.gb_max.BackColor = System.Drawing.Color.Transparent;
            this.gb_max.Controls.Add(this.vypisGarantMain);
            this.gb_max.Controls.Add(this.kb_edit);
            this.gb_max.Controls.Add(this.bt_addZaz);
            this.gb_max.Controls.Add(this.bt_delZaz);
            this.gb_max.Controls.Add(this.l_s8);
            this.gb_max.Controls.Add(this.l_s12);
            this.gb_max.Controls.Add(this.l_s11);
            this.gb_max.Controls.Add(this.l_s10);
            this.gb_max.Controls.Add(this.l_s9);
            this.gb_max.Controls.Add(this.l_s7);
            this.gb_max.Controls.Add(this.l_s6);
            this.gb_max.Controls.Add(this.l_s5);
            this.gb_max.Controls.Add(this.l_s4);
            this.gb_max.Controls.Add(this.l_s3);
            this.gb_max.Controls.Add(this.l_s2);
            this.gb_max.Controls.Add(this.l_s1);
            this.gb_max.Controls.Add(this.bt_zobrazDGar);
            this.gb_max.Controls.Add(this.l_vk);
            this.gb_max.Controls.Add(this.l_pvk);
            this.gb_max.Controls.Add(this.l_pkr);
            this.gb_max.Controls.Add(this.vypisPopisPredmet);
            this.gb_max.Controls.Add(this.nud_vKr);
            this.gb_max.Controls.Add(this.nud_pvKr);
            this.gb_max.Controls.Add(this.nud_pKr);
            this.gb_max.Controls.Add(this.lb_vyber);
            this.gb_max.Controls.Add(this.nud_PridatDoSem);
            this.gb_max.Controls.Add(this.label2);
            this.gb_max.Controls.Add(this.cmb_zaznam);
            this.gb_max.Controls.Add(this.bt_smaz);
            this.gb_max.Controls.Add(this.lb_semestr7);
            this.gb_max.Controls.Add(this.nud_KredSem12);
            this.gb_max.Controls.Add(this.nud_KredSem11);
            this.gb_max.Controls.Add(this.nud_KredSem10);
            this.gb_max.Controls.Add(this.nud_KredSem9);
            this.gb_max.Controls.Add(this.nud_KredSem8);
            this.gb_max.Controls.Add(this.nud_KredSem7);
            this.gb_max.Controls.Add(this.lb_semestr12);
            this.gb_max.Controls.Add(this.lb_semestr11);
            this.gb_max.Controls.Add(this.lb_semestr10);
            this.gb_max.Controls.Add(this.lb_semestr9);
            this.gb_max.Controls.Add(this.lb_semestr8);
            this.gb_max.Controls.Add(this.lb_semestr1);
            this.gb_max.Controls.Add(this.btn_pridat);
            this.gb_max.Controls.Add(this.lb_celkem);
            this.gb_max.Controls.Add(this.nud_KredSem6);
            this.gb_max.Controls.Add(this.nud_KredSem5);
            this.gb_max.Controls.Add(this.nud_KredSem4);
            this.gb_max.Controls.Add(this.nud_KredSem3);
            this.gb_max.Controls.Add(this.nud_KredSem2);
            this.gb_max.Controls.Add(this.nud_KredSem1);
            this.gb_max.Controls.Add(this.nud_celkemKred);
            this.gb_max.Controls.Add(this.lb_semestr6);
            this.gb_max.Controls.Add(this.lb_semestr5);
            this.gb_max.Controls.Add(this.lb_semestr4);
            this.gb_max.Controls.Add(this.lb_semestr3);
            this.gb_max.Controls.Add(this.lb_semestr2);
            this.gb_max.Cursor = System.Windows.Forms.Cursors.Default;
            this.gb_max.Location = new System.Drawing.Point(12, 26);
            this.gb_max.Name = "gb_max";
            this.gb_max.Size = new System.Drawing.Size(1074, 654);
            this.gb_max.TabIndex = 0;
            this.gb_max.TabStop = false;
            // 
            // kb_edit
            // 
            this.kb_edit.BackColor = System.Drawing.Color.DarkOrange;
            this.kb_edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kb_edit.FlatAppearance.BorderSize = 0;
            this.kb_edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.kb_edit.Image = global::SystemProPodporuStudijnichPlanu.Properties.Resources.edit;
            this.kb_edit.Location = new System.Drawing.Point(305, 11);
            this.kb_edit.Name = "kb_edit";
            this.kb_edit.Size = new System.Drawing.Size(25, 25);
            this.kb_edit.TabIndex = 64;
            this.toolTip_edit.SetToolTip(this.kb_edit, "Upravit záznam");
            this.kb_edit.UseVisualStyleBackColor = false;
            this.kb_edit.Click += new System.EventHandler(this.KulateButton1_Click);
            // 
            // bt_addZaz
            // 
            this.bt_addZaz.BackColor = System.Drawing.Color.White;
            this.bt_addZaz.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_addZaz.FlatAppearance.BorderSize = 0;
            this.bt_addZaz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_addZaz.Image = global::SystemProPodporuStudijnichPlanu.Properties.Resources._;
            this.bt_addZaz.Location = new System.Drawing.Point(275, 10);
            this.bt_addZaz.Name = "bt_addZaz";
            this.bt_addZaz.Size = new System.Drawing.Size(25, 25);
            this.bt_addZaz.TabIndex = 63;
            this.toolTip_new.SetToolTip(this.bt_addZaz, "Vytvořit nový záznam");
            this.bt_addZaz.UseVisualStyleBackColor = false;
            this.bt_addZaz.Click += new System.EventHandler(this.Bt_addZaz_Click);
            // 
            // bt_delZaz
            // 
            this.bt_delZaz.BackColor = System.Drawing.Color.White;
            this.bt_delZaz.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_delZaz.FlatAppearance.BorderSize = 0;
            this.bt_delZaz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_delZaz.Image = global::SystemProPodporuStudijnichPlanu.Properties.Resources.X;
            this.bt_delZaz.Location = new System.Drawing.Point(334, 11);
            this.bt_delZaz.Name = "bt_delZaz";
            this.bt_delZaz.Size = new System.Drawing.Size(25, 25);
            this.bt_delZaz.TabIndex = 65;
            this.toolTip_del.SetToolTip(this.bt_delZaz, "Smazat záznam");
            this.bt_delZaz.UseVisualStyleBackColor = false;
            this.bt_delZaz.Click += new System.EventHandler(this.Bt_delZaz_Click);
            // 
            // l_s8
            // 
            this.l_s8.AutoSize = true;
            this.l_s8.Location = new System.Drawing.Point(368, 147);
            this.l_s8.Name = "l_s8";
            this.l_s8.Size = new System.Drawing.Size(54, 13);
            this.l_s8.TabIndex = 94;
            this.l_s8.Text = "Semestr 8";
            // 
            // l_s12
            // 
            this.l_s12.AutoSize = true;
            this.l_s12.Location = new System.Drawing.Point(362, 554);
            this.l_s12.Name = "l_s12";
            this.l_s12.Size = new System.Drawing.Size(60, 13);
            this.l_s12.TabIndex = 93;
            this.l_s12.Text = "Semestr 12";
            // 
            // l_s11
            // 
            this.l_s11.AutoSize = true;
            this.l_s11.Location = new System.Drawing.Point(362, 451);
            this.l_s11.Name = "l_s11";
            this.l_s11.Size = new System.Drawing.Size(60, 13);
            this.l_s11.TabIndex = 92;
            this.l_s11.Text = "Semestr 11";
            // 
            // l_s10
            // 
            this.l_s10.AutoSize = true;
            this.l_s10.Location = new System.Drawing.Point(362, 350);
            this.l_s10.Name = "l_s10";
            this.l_s10.Size = new System.Drawing.Size(60, 13);
            this.l_s10.TabIndex = 91;
            this.l_s10.Text = "Semestr 10";
            // 
            // l_s9
            // 
            this.l_s9.AutoSize = true;
            this.l_s9.Location = new System.Drawing.Point(368, 247);
            this.l_s9.Name = "l_s9";
            this.l_s9.Size = new System.Drawing.Size(54, 13);
            this.l_s9.TabIndex = 90;
            this.l_s9.Text = "Semestr 9";
            // 
            // l_s7
            // 
            this.l_s7.AutoSize = true;
            this.l_s7.Location = new System.Drawing.Point(368, 45);
            this.l_s7.Name = "l_s7";
            this.l_s7.Size = new System.Drawing.Size(54, 13);
            this.l_s7.TabIndex = 89;
            this.l_s7.Text = "Semestr 7";
            // 
            // l_s6
            // 
            this.l_s6.AutoSize = true;
            this.l_s6.Location = new System.Drawing.Point(22, 554);
            this.l_s6.Name = "l_s6";
            this.l_s6.Size = new System.Drawing.Size(54, 13);
            this.l_s6.TabIndex = 88;
            this.l_s6.Text = "Semestr 6";
            // 
            // l_s5
            // 
            this.l_s5.AutoSize = true;
            this.l_s5.Location = new System.Drawing.Point(22, 451);
            this.l_s5.Name = "l_s5";
            this.l_s5.Size = new System.Drawing.Size(54, 13);
            this.l_s5.TabIndex = 87;
            this.l_s5.Text = "Semestr 5";
            // 
            // l_s4
            // 
            this.l_s4.AutoSize = true;
            this.l_s4.Location = new System.Drawing.Point(22, 350);
            this.l_s4.Name = "l_s4";
            this.l_s4.Size = new System.Drawing.Size(54, 13);
            this.l_s4.TabIndex = 86;
            this.l_s4.Text = "Semestr 4";
            // 
            // l_s3
            // 
            this.l_s3.AutoSize = true;
            this.l_s3.Location = new System.Drawing.Point(22, 247);
            this.l_s3.Name = "l_s3";
            this.l_s3.Size = new System.Drawing.Size(54, 13);
            this.l_s3.TabIndex = 85;
            this.l_s3.Text = "Semestr 3";
            // 
            // l_s2
            // 
            this.l_s2.AutoSize = true;
            this.l_s2.Location = new System.Drawing.Point(22, 147);
            this.l_s2.Name = "l_s2";
            this.l_s2.Size = new System.Drawing.Size(54, 13);
            this.l_s2.TabIndex = 84;
            this.l_s2.Text = "Semestr 2";
            // 
            // l_s1
            // 
            this.l_s1.AutoSize = true;
            this.l_s1.Location = new System.Drawing.Point(22, 45);
            this.l_s1.Name = "l_s1";
            this.l_s1.Size = new System.Drawing.Size(54, 13);
            this.l_s1.TabIndex = 83;
            this.l_s1.Text = "Semestr 1";
            // 
            // bt_zobrazDGar
            // 
            this.bt_zobrazDGar.BackColor = System.Drawing.Color.AntiqueWhite;
            this.bt_zobrazDGar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_zobrazDGar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt_zobrazDGar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.bt_zobrazDGar.Location = new System.Drawing.Point(682, 383);
            this.bt_zobrazDGar.Name = "bt_zobrazDGar";
            this.bt_zobrazDGar.Size = new System.Drawing.Size(97, 26);
            this.bt_zobrazDGar.TabIndex = 15;
            this.bt_zobrazDGar.Text = "Detail Garanta";
            this.toolTip_garant.SetToolTip(this.bt_zobrazDGar, "Zobrazit informace garanta vybraného předmětu");
            this.bt_zobrazDGar.UseVisualStyleBackColor = false;
            this.bt_zobrazDGar.Visible = false;
            this.bt_zobrazDGar.Click += new System.EventHandler(this.Bt_zobrazDGar_Click);
            // 
            // l_vk
            // 
            this.l_vk.AutoSize = true;
            this.l_vk.Location = new System.Drawing.Point(855, 627);
            this.l_vk.Name = "l_vk";
            this.l_vk.Size = new System.Drawing.Size(151, 13);
            this.l_vk.TabIndex = 80;
            this.l_vk.Text = "Kredity z volitelných předmětů:";
            // 
            // l_pvk
            // 
            this.l_pvk.AutoSize = true;
            this.l_pvk.Location = new System.Drawing.Point(862, 601);
            this.l_pvk.Name = "l_pvk";
            this.l_pvk.Size = new System.Drawing.Size(144, 13);
            this.l_pvk.TabIndex = 79;
            this.l_pvk.Text = "Kredity z povinně-volitelných:";
            // 
            // l_pkr
            // 
            this.l_pkr.AutoSize = true;
            this.l_pkr.Location = new System.Drawing.Point(856, 575);
            this.l_pkr.Name = "l_pkr";
            this.l_pkr.Size = new System.Drawing.Size(150, 13);
            this.l_pkr.TabIndex = 78;
            this.l_pkr.Text = "Kredity z povinných předmětů:";
            // 
            // vypisPopisPredmet
            // 
            this.vypisPopisPredmet.Cviceni = "";
            this.vypisPopisPredmet.Garant = "";
            this.vypisPopisPredmet.Jazyk = "";
            this.vypisPopisPredmet.Kombi = "";
            this.vypisPopisPredmet.Kredit = "";
            this.vypisPopisPredmet.Lab = "";
            this.vypisPopisPredmet.Location = new System.Drawing.Point(680, 38);
            this.vypisPopisPredmet.Name = "vypisPopisPredmet";
            this.vypisPopisPredmet.P = null;
            this.vypisPopisPredmet.Popis = "";
            this.vypisPopisPredmet.Povinnost = "";
            this.vypisPopisPredmet.Prednaska = "";
            this.vypisPopisPredmet.Prerekvizita = "";
            this.vypisPopisPredmet.Semestr = "";
            this.vypisPopisPredmet.Size = new System.Drawing.Size(389, 337);
            this.vypisPopisPredmet.TabIndex = 77;
            this.vypisPopisPredmet.Visible = false;
            this.vypisPopisPredmet.Zakončení = "";
            this.vypisPopisPredmet.Zkr = "";
            // 
            // nud_vKr
            // 
            this.nud_vKr.BackColor = System.Drawing.Color.White;
            this.nud_vKr.Enabled = false;
            this.nud_vKr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_vKr.Location = new System.Drawing.Point(1012, 625);
            this.nud_vKr.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_vKr.Name = "nud_vKr";
            this.nud_vKr.ReadOnly = true;
            this.nud_vKr.Size = new System.Drawing.Size(55, 20);
            this.nud_vKr.TabIndex = 76;
            this.nud_vKr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_pvKr
            // 
            this.nud_pvKr.BackColor = System.Drawing.Color.White;
            this.nud_pvKr.Enabled = false;
            this.nud_pvKr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_pvKr.Location = new System.Drawing.Point(1012, 599);
            this.nud_pvKr.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_pvKr.Name = "nud_pvKr";
            this.nud_pvKr.ReadOnly = true;
            this.nud_pvKr.Size = new System.Drawing.Size(55, 20);
            this.nud_pvKr.TabIndex = 75;
            this.nud_pvKr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nud_pKr
            // 
            this.nud_pKr.BackColor = System.Drawing.Color.White;
            this.nud_pKr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.nud_pKr.Enabled = false;
            this.nud_pKr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_pKr.Location = new System.Drawing.Point(1012, 573);
            this.nud_pKr.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_pKr.Name = "nud_pKr";
            this.nud_pKr.ReadOnly = true;
            this.nud_pKr.Size = new System.Drawing.Size(55, 20);
            this.nud_pKr.TabIndex = 74;
            this.nud_pKr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lb_vyber
            // 
            this.lb_vyber.AutoSize = true;
            this.lb_vyber.Location = new System.Drawing.Point(425, 16);
            this.lb_vyber.Name = "lb_vyber";
            this.lb_vyber.Size = new System.Drawing.Size(76, 13);
            this.lb_vyber.TabIndex = 70;
            this.lb_vyber.Text = "Vyber semestr:";
            // 
            // nud_PridatDoSem
            // 
            this.nud_PridatDoSem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nud_PridatDoSem.Location = new System.Drawing.Point(508, 12);
            this.nud_PridatDoSem.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.nud_PridatDoSem.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_PridatDoSem.Name = "nud_PridatDoSem";
            this.nud_PridatDoSem.Size = new System.Drawing.Size(55, 20);
            this.nud_PridatDoSem.TabIndex = 13;
            this.nud_PridatDoSem.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.toolTip_sem.SetToolTip(this.nud_PridatDoSem, "Výběr do jakého semestru chceme přidat předměty");
            this.nud_PridatDoSem.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // vypisGarantMain
            // 
            this.vypisGarantMain.Email = "";
            this.vypisGarantMain.G = null;
            this.vypisGarantMain.Katedra = "";
            this.vypisGarantMain.Konzultace = "";
            this.vypisGarantMain.Location = new System.Drawing.Point(780, 380);
            this.vypisGarantMain.Name = "vypisGarantMain";
            this.vypisGarantMain.Size = new System.Drawing.Size(287, 141);
            this.vypisGarantMain.TabIndex = 95;
            this.vypisGarantMain.Telefon = "";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1094, 688);
            this.Controls.Add(this.gb_max);
            this.Controls.Add(this.menuStripMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStripMain;
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Systém pro podporu tvorby studijních plánů";
            this.menuStripMain.ResumeLayout(false);
            this.menuStripMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_celkemKred)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_KredSem12)).EndInit();
            this.gb_max.ResumeLayout(false);
            this.gb_max.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_vKr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_pvKr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_pKr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PridatDoSem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStripMain;
        private System.Windows.Forms.ToolStripMenuItem souborToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem konecToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nápovědaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem správaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oAplikaciToolStripMenuItem;
        private System.Windows.Forms.ListBox lb_semestr2;
        private System.Windows.Forms.ListBox lb_semestr3;
        private System.Windows.Forms.ListBox lb_semestr4;
        private System.Windows.Forms.ListBox lb_semestr5;
        private System.Windows.Forms.ListBox lb_semestr6;
        private System.Windows.Forms.NumericUpDown nud_celkemKred;
        private System.Windows.Forms.NumericUpDown nud_KredSem1;
        private System.Windows.Forms.NumericUpDown nud_KredSem2;
        private System.Windows.Forms.NumericUpDown nud_KredSem3;
        private System.Windows.Forms.NumericUpDown nud_KredSem4;
        private System.Windows.Forms.NumericUpDown nud_KredSem5;
        private System.Windows.Forms.NumericUpDown nud_KredSem6;
        private System.Windows.Forms.Label lb_celkem;
        private System.Windows.Forms.Button btn_pridat;
        private System.Windows.Forms.ListBox lb_semestr1;
        private System.Windows.Forms.ListBox lb_semestr8;
        private System.Windows.Forms.ListBox lb_semestr9;
        private System.Windows.Forms.ListBox lb_semestr10;
        private System.Windows.Forms.ListBox lb_semestr11;
        private System.Windows.Forms.ListBox lb_semestr12;
        private System.Windows.Forms.NumericUpDown nud_KredSem7;
        private System.Windows.Forms.NumericUpDown nud_KredSem8;
        private System.Windows.Forms.NumericUpDown nud_KredSem9;
        private System.Windows.Forms.NumericUpDown nud_KredSem10;
        private System.Windows.Forms.NumericUpDown nud_KredSem11;
        private System.Windows.Forms.NumericUpDown nud_KredSem12;
        private System.Windows.Forms.ListBox lb_semestr7;
        private System.Windows.Forms.Button bt_smaz;
        private System.Windows.Forms.ComboBox cmb_zaznam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gb_max;
        private System.Windows.Forms.NumericUpDown nud_PridatDoSem;
        private System.Windows.Forms.Label lb_vyber;
        private System.Windows.Forms.ToolStripMenuItem vytvořitNovýZáznamToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem upravitZáznamToolStripMenuItem;
        private System.Windows.Forms.NumericUpDown nud_vKr;
        private System.Windows.Forms.NumericUpDown nud_pvKr;
        private System.Windows.Forms.NumericUpDown nud_pKr;
        private System.Windows.Forms.Label l_vk;
        private System.Windows.Forms.Label l_pvk;
        private System.Windows.Forms.Label l_pkr;
        private Komponenty.VypisPopisPredmet vypisPopisPredmet;
        private System.Windows.Forms.Button bt_zobrazDGar;
        private System.Windows.Forms.Label l_s8;
        private System.Windows.Forms.Label l_s12;
        private System.Windows.Forms.Label l_s11;
        private System.Windows.Forms.Label l_s10;
        private System.Windows.Forms.Label l_s9;
        private System.Windows.Forms.Label l_s7;
        private System.Windows.Forms.Label l_s6;
        private System.Windows.Forms.Label l_s5;
        private System.Windows.Forms.Label l_s4;
        private System.Windows.Forms.Label l_s3;
        private System.Windows.Forms.Label l_s2;
        private System.Windows.Forms.Label l_s1;
        private Icons.KulateButton bt_delZaz;
        private Icons.KulateButton bt_addZaz;
        private Icons.KulateButton kb_edit;
        private System.Windows.Forms.ToolTip toolTip_edit;
        private System.Windows.Forms.ToolTip toolTip_new;
        private System.Windows.Forms.ToolTip toolTip_del;
        private System.Windows.Forms.ToolTip toolTip_pridat;
        private System.Windows.Forms.ToolTip toolTip_smaz;
        private System.Windows.Forms.ToolTip toolTip_sem;
        private System.Windows.Forms.ToolTip toolTip_garant;
        private Komponenty.VypisGarant vypisGarantMain;
    }
}

