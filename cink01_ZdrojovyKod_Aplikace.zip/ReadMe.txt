Pro funkční instalaci je zapotřebí mít podporu pro spouštění .NET aplikací. 
Nejednodušší cesta je nainstalování Visual Studia 2017 nebo 2019 alespoň community verze, kde se vyberou moduly na .Net (.NET desktop development) a SQL servery (Data storage and processing). 
Poté lze úspěšně nainstalovat či spustit aplikaci. 

Při prvním spuštění kódu je zapotřebí nejprve setavit řešení, aby se načetly všechny části vlastních komponent.